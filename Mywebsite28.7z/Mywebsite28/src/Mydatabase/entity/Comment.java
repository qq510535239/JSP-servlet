package Mydatabase.entity;

public class Comment {

	private String tnumber;
	private int dnumber;
	private String name;
	private String time;
	private String content;
	
	public Comment(String Content,String Name,String Time)
	{
		this.content=Content;
		this.name=Name;
		this.time=Time;
	}
	
	public Comment(String Tnumber,int Dnumber,String Name,String Time,String Content)
	{
		this.tnumber=Tnumber;
		this.dnumber=Dnumber;
		this.name=Name;
		this.time=Time;
		this.content=Content;
	}

	public String getTnumber() {
		return tnumber;
	}

	public void setTnumber(String tnumber) {
		this.tnumber = tnumber;
	}

	public int getDnumber() {
		return dnumber;
	}

	public void setDnumber(int dnumber) {
		this.dnumber = dnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	
	
}

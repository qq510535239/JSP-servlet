package Mydatabase.entity;

public class Addmessages {
	private int id;
	private int number;
	private String name;
	private String title;
	private String content;
	private String time;
	public Addmessages(int ID,int Number,String Name,String Title,String Content,String Time)
	{
		this.id=ID;
		this.number=Number;
		this.name=Name;
		this.title=Title;
		this.content=Content;
		this.time=Time;
	}
	
	public Addmessages(int Number,String Name,String Title,String Content,String Time)
	{
		this.number=Number;
		this.name=Name;
		this.title=Title;
		this.content=Content;
		this.time=Time;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
}


package Mydatabase.dao;


public class DataDaoDelete extends DataDao{

	public void deleteByUsernumber(String number)
	{
		String sql="delete from User where number='"+number+"'";
		this.exceutUpdate(sql);
	}
}

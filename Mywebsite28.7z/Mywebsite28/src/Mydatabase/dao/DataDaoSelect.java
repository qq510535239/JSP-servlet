package Mydatabase.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;





import Mydatabase.entity.*;

public class DataDaoSelect extends DataDao {
	
	//��¼��ѯ
	public boolean login(User user)
	{
		boolean result=false;
		String sql="select * from User where name='"+user.getName()+"'and password='"+user.getPassword()+"'";
		try
		{
			ResultSet rs=this.excueteQuery(sql);
			if(rs.next())
			{
				result=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			this.closeAll(conn, stmt, rs);
		}
		return result;
	}
	
	//����ǰ�û�����ѯȡ�����ֺ��˺�
		public List<User> loginname(String Name)
		{
			List<User> list=new ArrayList<User>();
			String sql="select * from User where name='"+Name+"'";
			try
			{
				ResultSet rs=this.excueteQuery(sql);
				if(rs.next())
				{
					String name=rs.getString("name");
					int number=rs.getInt("number");
					String type=rs.getString("type");
					
					User user1=new User(name,number,type);
					list.add(user1);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				this.closeAll(conn, stmt, rs);
			}
			return list;
		}
		//��ѯȫ��������Ϣ
		public List<Addmessages> selectAddmessages()
		{
			List<Addmessages> list=new ArrayList<Addmessages>();
			String sql="select * from Addmessages";
			ResultSet rs=this.excueteQuery(sql);
			try
			{
				while(rs.next())
				{
					int id=rs.getInt("id");
					int number=rs.getInt("number");
					String name=rs.getString("name");
					String title=rs.getString("title");
					String content=rs.getString("content");
					String time=rs.getString("time");
					Addmessages book=new Addmessages(id,number,name,title,content,time);
					list.add(book);
				}
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				this.closeAll(conn, stmt, rs);
			}
			return list;
		}
		//��ID��ѯ��һ������
		public List<Addmessages> selectAddmessages(String uid)
		{
			List<Addmessages> list=new ArrayList<Addmessages>();
			String sql="select * from Addmessages where id='"+uid+"'";
			ResultSet rs=this.excueteQuery(sql);
			try
			{
				while(rs.next())
				{
					int id=rs.getInt("id");
					int number=rs.getInt("number");
					String name=rs.getString("name");
					String title=rs.getString("title");
					String content=rs.getString("content");
					String time=rs.getString("time");
					Addmessages book=new Addmessages(id,number,name,title,content,time);
					list.add(book);
				}
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				this.closeAll(conn, stmt, rs);
			}
			return list;
		}
	
		//��ѯ�Դ�����������������Ϣ
		
		public List<Comment> selectComment(String tit)
		{
			List<Comment> list=new ArrayList<Comment>();
			String sql="SELECT c.content,c.name,c.time FROM Comment c,Addmessages g where c.tnumber=g.number and g.title='"+tit+"'";
			ResultSet rs=this.excueteQuery(sql);
			try
			{
				while(rs.next())
				{
					String content=rs.getString("content");
					String name=rs.getString("name");
					String time=rs.getString("time");
					Comment comment=new Comment(content,name,time);
					list.add(comment);
				}
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				this.closeAll(conn, stmt, rs);
			}
			return list;
		}
			
		//��ѯ�����û�����Ϣ
				public List<User> selectAdmin()
				{
					List<User> list=new ArrayList<User>();
					String sql="select * from User";
					ResultSet rs=this.excueteQuery(sql);
					try
					{
						while(rs.next())
						{
							int number=rs.getInt("number");
							String name=rs.getString("name");
							String password=rs.getString("password");
							String sex=rs.getString("sex");
							String type=rs.getString("type");
							String phone=rs.getString("phone");
							String email=rs.getString("email");
							String birthday=rs.getString("birthday");
							
							User user=new User(number,name,password,sex,type,phone,email,birthday);
							list.add(user);
						}
							
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					finally
					{
						this.closeAll(conn, stmt, rs);
					}
					
					return list;
				}
				
				//��number�˺Ų�ѯ�û�����Ϣ
						public List<User> selectAdmin(String Number)
						{
							List<User> list=new ArrayList<User>();
							String sql="select * from User where number='"+Number+"'";
							ResultSet rs=this.excueteQuery(sql);
							try
							{
								while(rs.next())
								{
									int number=rs.getInt("number");
									String name=rs.getString("name");
									String password=rs.getString("password");
									String sex=rs.getString("sex");
									String type=rs.getString("type");
									String phone=rs.getString("phone");
									String email=rs.getString("email");
									String birthday=rs.getString("birthday");
									
									User user=new User(number,name,password,sex,type,phone,email,birthday);
									list.add(user);
								}
									
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							finally
							{
								this.closeAll(conn, stmt, rs);
							}
							
							return list;
						}
	
}

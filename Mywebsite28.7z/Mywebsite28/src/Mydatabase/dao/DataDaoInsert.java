package Mydatabase.dao;


import Mydatabase.entity.*;

public class DataDaoInsert extends DataDao{
	
	//ע���û�
	public int insertUser(User user)
	{
		int i;
		String sql="insert into User(number,name,password,sex,type,phone,email,birthday) values('"+user.getNumber()+"','"+user.getName()+"','"+user.getPassword()+"','"+user.getSex()+"','"+user.getType()+"','"+user.getPhone()+"','"+user.getEmail()+"','"+user.getBirthday()+"')";
		i=this.exceutUpdate(sql);
		return i;
	}
	//���ӷ���������Ϣ
		public int insertAddmessages(Addmessages addmessages)
		{
			int i;
			String sql="insert into Addmessages(number,name,title,content,time) values('"+addmessages.getNumber()+"','"+addmessages.getName()+"','"+addmessages.getTitle()+"','"+addmessages.getContent()+"','"+addmessages.getTime()+"')";
			i=this.exceutUpdate(sql);
			return i;
		}
		
		//���Իظ�
		public int insertComment(Comment comment)
		{
			int i;
			String sql="insert into Comment(tnumber,dnumber,name,time,content) values('"+comment.getTnumber()+"','"+comment.getDnumber()+"','"+comment.getName()+"','"+comment.getTime()+"','"+comment.getContent()+"')";
			i=this.exceutUpdate(sql);
			return i;
		}


}

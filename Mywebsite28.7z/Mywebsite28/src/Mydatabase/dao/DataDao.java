package Mydatabase.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataDao {

	protected Connection conn=null;
	protected Statement stmt=null;
	protected ResultSet rs=null;
	public String driver="com.mysql.jdbc.Driver";
	public String url="jdbc:mysql://localhost:3306/mydatabase22";
	public String user="root";
	public String password="root";
	
	public Connection getConnection()
	{
		Connection con=null;
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

//
	
	public void closeAll(Connection conn,Statement stmt,ResultSet rs)
	{
		if(rs!=null)
		{
			try
			{
				rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(stmt!=null)
		{
			try
			{
				rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(conn!=null)
		{
			try
			{
				rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
//
	
	public int exceutUpdate(String sql)
	{
		int i=0;
		conn=this.getConnection();
		try
		{
			stmt=conn.createStatement();
			i=stmt.executeUpdate(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return i;
	}
	
//��ѯ
	public ResultSet excueteQuery(String sql)
	{
		conn=this.getConnection();
		try
		{
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}
	
}

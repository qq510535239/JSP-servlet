package Mydatabase.dao;

import Mydatabase.entity.*;


public class DataDaoUpdate extends DataDao{

	public void updateByUserNumber(User user)
	{
		String sql="update User Set name='"+user.getName()+"',password='"+user.getPassword()+"',sex='"+user.getSex()+"',type='"+user.getType()+"',phone='"+user.getPhone()+"',email='"+user.getEmail()+"',birthday='"+user.getBirthday()+"' where number='"+user.getNumber()+"'";
		this.exceutUpdate(sql);
	}
}
